const Mission = require('../models/Mission');

const seedMissions = async () => {
  try {
    // Check if there are already records
    const count = await Mission.countDocuments();
    if (count > 0) {
      console.log('[Database] Seed: Las misiones espaciales ya existen en la base de datos.');
      return;
    }

    // Mock Data
    const mockMissions = [
      {
        title: 'Rover Expedition Artemis III',
        destination: 'Luna (Polo Sur - Cráter Shackleton)',
        commander: 'Dr. Helena Vance',
        launchDate: new Date('2026-08-12T00:00:00Z'),
        status: 'Planned',
        budget: 45000000,
        description: 'Despliegue del explorador solar con el fin de perforar regolito profundo y localizar reservas de hielo de agua.'
      },
      {
        title: 'Probe Voyager Neo-5',
        destination: 'Europa (Satélite de Júpiter)',
        commander: 'Dr. Sarah Connor',
        launchDate: new Date('2026-12-25T00:00:00Z'),
        status: 'In Progress',
        budget: 135500000,
        description: 'Sonda orbital automatizada para el escaneo espectrográfico de fracturas de hielo y mapeo de océanos subsuperficiales.'
      },
      {
        title: 'Dragonfly Titan Atmospheric Drone',
        destination: 'Titán (Satélite de Saturno)',
        commander: 'Capt. Joseph Cooper',
        launchDate: new Date('2025-05-18T00:00:00Z'),
        status: 'Completed',
        budget: 98000000,
        description: 'Misión robótica aérea de reconocimiento atmosférico y muestreo químico de dunas de hidrocarburos sólidos.'
      }
    ];

    await Mission.insertMany(mockMissions);
    console.log('[Database] Seed: Misiones iniciales registradas en la base de datos con éxito.');
  } catch (error) {
    console.error(`[Database] Error al sembrar datos: ${error.message}`);
  }
};

module.exports = seedMissions;
