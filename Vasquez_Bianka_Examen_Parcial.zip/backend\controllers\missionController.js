const Mission = require('../models/Mission');

// Helper to check for Mongoose CastError (invalid ObjectId format)
const handleCastError = (err, res) => {
  if (err.name === 'CastError') {
    return res.status(400).json({
      success: false,
      message: `ID con formato inválido: ${err.value}`
    });
  }
  return res.status(500).json({
    success: false,
    message: 'Error interno del servidor.',
    error: err.message
  });
};

// @desc    Obtener todas las misiones
// @route   GET /api/missions
// @access  Public
exports.getMissions = async (req, res) => {
  try {
    const missions = await Mission.find().sort({ createdAt: -1 });
    return res.status(200).json({
      success: true,
      count: missions.length,
      data: missions
    });
  } catch (err) {
    return res.status(500).json({
      success: false,
      message: 'Error al obtener las misiones.',
      error: err.message
    });
  }
};

// @desc    Obtener una misión específica
// @route   GET /api/missions/:id
// @access  Public
exports.getMissionById = async (req, res) => {
  try {
    const mission = await Mission.findById(req.params.id);
    
    if (!mission) {
      return res.status(404).json({
        success: false,
        message: `Misión no encontrada con el ID: ${req.params.id}`
      });
    }

    return res.status(200).json({
      success: true,
      data: mission
    });
  } catch (err) {
    return handleCastError(err, res);
  }
};

// @desc    Crear una nueva misión
// @route   POST /api/missions
// @access  Public
exports.createMission = async (req, res) => {
  try {
    const mission = await Mission.create(req.body);
    return res.status(201).json({
      success: true,
      message: 'Misión espacial creada con éxito.',
      data: mission
    });
  } catch (err) {
    if (err.name === 'ValidationError') {
      const messages = Object.values(err.errors).map(val => val.message);
      return res.status(400).json({
        success: false,
        message: 'Error de validación en los datos de la misión.',
        errors: messages
      });
    }
    return res.status(500).json({
      success: false,
      message: 'Error al crear la misión.',
      error: err.message
    });
  }
};

// @desc    Actualizar una misión existente
// @route   PUT /api/missions/:id
// @access  Public
exports.updateMission = async (req, res) => {
  try {
    const mission = await Mission.findByIdAndUpdate(
      req.params.id, 
      req.body, 
      {
        new: true, // Return modified document
        runValidators: true // Run schema validations
      }
    );

    if (!mission) {
      return res.status(404).json({
        success: false,
        message: `No se encontró la misión con el ID: ${req.params.id}`
      });
    }

    return res.status(200).json({
      success: true,
      message: 'Misión espacial actualizada con éxito.',
      data: mission
    });
  } catch (err) {
    if (err.name === 'ValidationError') {
      const messages = Object.values(err.errors).map(val => val.message);
      return res.status(400).json({
        success: false,
        message: 'Error de validación en la actualización.',
        errors: messages
      });
    }
    return handleCastError(err, res);
  }
};

// @desc    Eliminar una misión
// @route   DELETE /api/missions/:id
// @access  Public
exports.deleteMission = async (req, res) => {
  try {
    const mission = await Mission.findByIdAndDelete(req.params.id);

    if (!mission) {
      return res.status(404).json({
        success: false,
        message: `No se encontró la misión con el ID: ${req.params.id}`
      });
    }

    return res.status(200).json({
      success: true,
      message: 'Misión espacial eliminada del registro.',
      data: {}
    });
  } catch (err) {
    return handleCastError(err, res);
  }
};
