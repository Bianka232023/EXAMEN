const express = require('express');
const router = express.Router();
const {
  getMissions,
  getMissionById,
  createMission,
  updateMission,
  deleteMission
} = require('../controllers/missionController');

// Routes for /api/missions
router.route('/')
  .get(getMissions)
  .post(createMission);

// Routes for /api/missions/:id
router.route('/:id')
  .get(getMissionById)
  .put(updateMission)
  .delete(deleteMission);

module.exports = router;
