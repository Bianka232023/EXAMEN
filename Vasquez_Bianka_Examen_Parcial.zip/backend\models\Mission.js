const mongoose = require('mongoose');

const MissionSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, 'El título de la misión es obligatorio.'],
    trim: true
  },
  destination: {
    type: String,
    required: [true, 'El destino de la misión es obligatorio.'],
    trim: true
  },
  commander: {
    type: String,
    required: [true, 'El nombre del comandante es obligatorio.'],
    trim: true
  },
  launchDate: {
    type: Date,
    required: [true, 'La fecha de lanzamiento es obligatoria.']
  },
  status: {
    type: String,
    required: [true, 'El estado de la misión es obligatorio.'],
    enum: {
      values: ['Planned', 'In Progress', 'Completed', 'Aborted'],
      message: '{VALUE} no es un estado válido (Planned, In Progress, Completed, Aborted).'
    },
    default: 'Planned'
  },
  budget: {
    type: Number,
    required: [true, 'El presupuesto es obligatorio.'],
    min: [0, 'El presupuesto no puede ser menor a 0.']
  },
  description: {
    type: String,
    required: [true, 'La descripción de la misión es obligatoria.'],
    trim: true
  }
}, {
  timestamps: true // Adds createdAt and updatedAt automatically
});

module.exports = mongoose.model('Mission', MissionSchema);
