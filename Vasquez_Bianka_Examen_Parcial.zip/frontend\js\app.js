// Nova Space Command Console - Client Controller
document.addEventListener('DOMContentLoaded', () => {
  
  // Detect server connection path dynamically
  const API_URL = (window.location.origin.includes('http') && !window.location.pathname.endsWith('.html'))
    ? '/api/missions'
    : 'http://localhost:5000/api/missions';

  // State Management
  let allMissions = [];
  let bootstrapEditModal = null;
  let bootstrapDeleteModal = null;

  // DOM Elements
  const loader = document.getElementById('loader');
  const missionsContainer = document.getElementById('missionsContainer');
  const createForm = document.getElementById('createMissionForm');
  const editForm = document.getElementById('editMissionForm');
  const confirmDeleteBtn = document.getElementById('confirmDeleteBtn');
  
  // Filter Inputs
  const searchFilter = document.getElementById('searchFilter');
  const statusFilter = document.getElementById('statusFilter');

  // Telemetry widgets
  const statTotal = document.getElementById('statTotal');
  const statInProgress = document.getElementById('statInProgress');
  const statBudget = document.getElementById('statBudget');
  const statCompleted = document.getElementById('statCompleted');

  // Initialize bootstrap modals
  if (document.getElementById('editMissionModal')) {
    bootstrapEditModal = new bootstrap.Modal(document.getElementById('editMissionModal'));
  }
  if (document.getElementById('deleteConfirmModal')) {
    bootstrapDeleteModal = new bootstrap.Modal(document.getElementById('deleteConfirmModal'));
  }

  // --- Fetch & Render Operations ---

  // Fetch all missions from API
  async function fetchMissions() {
    showLoader();
    try {
      const response = await fetch(API_URL);
      const resData = await response.json();
      
      if (resData.success) {
        allMissions = resData.data;
        renderMissions(allMissions);
        updateTelemetry(allMissions);
      } else {
        showToast('Error al leer el registro de misiones.', 'error');
      }
    } catch (error) {
      console.error('Fetch error:', error);
      showToast('No se pudo conectar con el servidor de comando.', 'error');
      // Render placeholder error
      missionsContainer.innerHTML = `
        <div class="col-12 text-center py-5">
          <i class="bi bi-wifi-off text-danger fs-1"></i>
          <h3 class="h6 mt-3 text-danger font-space-grotesk uppercase-tracking">ENLACE CAÍDO</h3>
          <p class="text-muted fs-sm">El servidor no responde en ${API_URL}. Revisa la conexión del backend.</p>
        </div>
      `;
    } finally {
      hideLoader();
    }
  }

  // Update telemetry dashboard statistics
  function updateTelemetry(missions) {
    const total = missions.length;
    const inProgress = missions.filter(m => m.status === 'In Progress').length;
    const completed = missions.filter(m => m.status === 'Completed').length;
    
    // Sum budgets (convert to Millions for neatness if appropriate)
    const sumBudget = missions.reduce((acc, curr) => acc + (curr.budget || 0), 0);
    
    statTotal.textContent = total;
    statInProgress.textContent = inProgress;
    statCompleted.textContent = completed;
    
    // Formatting budget
    if (sumBudget >= 1000000) {
      statBudget.textContent = `$${(sumBudget / 1000000).toFixed(1)}M`;
    } else {
      statBudget.textContent = `$${sumBudget.toLocaleString()}`;
    }
  }

  // Render missions cards list
  function renderMissions(missions) {
    missionsContainer.innerHTML = '';
    
    if (missions.length === 0) {
      missionsContainer.innerHTML = `
        <div class="col-12 text-center py-5 fade-in-up">
          <i class="bi bi-journal-x text-muted fs-2"></i>
          <p class="text-muted fs-sm mt-3">Sin registros espaciales que coincidan con la búsqueda.</p>
        </div>
      `;
      return;
    }

    missions.forEach(mission => {
      const cardCol = document.createElement('div');
      cardCol.className = 'col-md-6 fade-in-up';
      
      // Determine status translations and status colors
      let statusLabel = 'Planificada';
      let statusClass = 'Planned';
      let statusColor = '#4facfe'; // Hex colors matching CSS
      
      switch(mission.status) {
        case 'In Progress':
          statusLabel = 'En Curso';
          statusClass = 'InProgress';
          statusColor = '#f5af19';
          break;
        case 'Completed':
          statusLabel = 'Completada';
          statusClass = 'Completed';
          statusColor = '#11998e';
          break;
        case 'Aborted':
          statusLabel = 'Abortada';
          statusClass = 'Aborted';
          statusColor = '#f857a6';
          break;
      }

      // Format Date
      const dateFormatted = new Date(mission.launchDate).toLocaleDateString('es-ES', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        timeZone: 'UTC'
      });

      // Build card inner HTML
      cardCol.innerHTML = `
        <div class="mission-card" style="--status-color: ${statusColor};">
          <div class="d-flex justify-content-between align-items-start mb-3 gap-2">
            <h3 class="mission-title mb-0" title="${mission.title}">${mission.title}</h3>
            <span class="badge status-badge-${statusClass} fs-xs font-space-grotesk uppercase-tracking">${statusLabel}</span>
          </div>
          
          <div class="mission-meta-item">
            <i class="bi bi-compass"></i><strong>Destino:</strong> ${mission.destination}
          </div>
          <div class="mission-meta-item">
            <i class="bi bi-person-badge"></i><strong>Comandante:</strong> ${mission.commander}
          </div>
          <div class="mission-meta-item">
            <i class="bi bi-calendar-event"></i><strong>Lanzamiento:</strong> ${dateFormatted}
          </div>
          <div class="mission-meta-item">
            <i class="bi bi-cash-stack"></i><strong>Presupuesto:</strong> $${mission.budget.toLocaleString()} USD
          </div>
          
          <p class="mission-description">${mission.description}</p>
          
          <div class="d-flex justify-content-end gap-2 border-top border-secondary border-opacity-25 pt-3">
            <button class="btn btn-sm btn-outline-glow-info edit-btn" data-id="${mission._id}">
              <i class="bi bi-pencil-square me-1"></i>Editar
            </button>
            <button class="btn btn-sm btn-outline-danger delete-btn" data-id="${mission._id}" style="border: 1px solid rgba(248,87,166,0.3); color:#f857a6;">
              <i class="bi bi-trash3 me-1"></i>Purgar
            </button>
          </div>
        </div>
      `;
      
      // Bind Edit Button Click
      cardCol.querySelector('.edit-btn').addEventListener('click', () => loadEditModal(mission._id));
      
      // Bind Delete Button Click
      cardCol.querySelector('.delete-btn').addEventListener('click', () => {
        document.getElementById('deleteMissionId').value = mission._id;
        bootstrapDeleteModal.show();
      });

      missionsContainer.appendChild(cardCol);
    });
  }

  // --- CRUD API Actions ---

  // POST: Create new mission
  createForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    // Front validation
    if (!createForm.checkValidity()) {
      showToast('Por favor complete todos los parámetros requeridos.', 'warning');
      createForm.classList.add('was-validated');
      return;
    }

    const payload = {
      title: document.getElementById('title').value,
      destination: document.getElementById('destination').value,
      commander: document.getElementById('commander').value,
      launchDate: document.getElementById('launchDate').value,
      status: document.getElementById('status').value,
      budget: parseFloat(document.getElementById('budget').value),
      description: document.getElementById('description').value
    };

    try {
      const response = await fetch(API_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      });

      const resData = await response.json();

      if (response.status === 201) {
        showToast(resData.message || 'Misión registrada en la bitácora.', 'success');
        createForm.reset();
        createForm.classList.remove('was-validated');
        fetchMissions();
      } else {
        // Validation error or bad request
        const errorMsg = resData.errors ? resData.errors.join(', ') : resData.message;
        showToast(`Fallo de Registro: ${errorMsg}`, 'error');
      }
    } catch (error) {
      console.error('Error creating mission:', error);
      showToast('Fallo de red al enviar registros de misión.', 'error');
    }
  });

  // Load details into the Modal Form for PUT
  async function loadEditModal(id) {
    try {
      const response = await fetch(`${API_URL}/${id}`);
      const resData = await response.json();
      
      if (resData.success) {
        const mission = resData.data;
        
        // Populate inputs
        document.getElementById('editMissionId').value = mission._id;
        document.getElementById('editTitle').value = mission.title;
        document.getElementById('editDestination').value = mission.destination;
        document.getElementById('editCommander').value = mission.commander;
        
        // Date formatting for input type="date" (YYYY-MM-DD)
        const rawDate = new Date(mission.launchDate);
        const isoDate = rawDate.toISOString().split('T')[0];
        document.getElementById('editLaunchDate').value = isoDate;
        
        document.getElementById('editStatus').value = mission.status;
        document.getElementById('editBudget').value = mission.budget;
        document.getElementById('editDescription').value = mission.description;
        
        editForm.classList.remove('was-validated');
        bootstrapEditModal.show();
      } else {
        showToast('No se pudieron obtener los datos de la misión.', 'error');
      }
    } catch (error) {
      console.error('Error fetching single mission:', error);
      showToast('Error de red al consultar los registros.', 'error');
    }
  }

  // PUT: Update existing mission
  editForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    if (!editForm.checkValidity()) {
      showToast('Por favor complete todos los parámetros requeridos.', 'warning');
      editForm.classList.add('was-validated');
      return;
    }

    const id = document.getElementById('editMissionId').value;
    const payload = {
      title: document.getElementById('editTitle').value,
      destination: document.getElementById('editDestination').value,
      commander: document.getElementById('editCommander').value,
      launchDate: document.getElementById('editLaunchDate').value,
      status: document.getElementById('editStatus').value,
      budget: parseFloat(document.getElementById('editBudget').value),
      description: document.getElementById('editDescription').value
    };

    try {
      const response = await fetch(`${API_URL}/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      });

      const resData = await response.json();

      if (response.ok) {
        showToast(resData.message || 'Misión espacial modificada.', 'success');
        bootstrapEditModal.hide();
        fetchMissions();
      } else {
        const errorMsg = resData.errors ? resData.errors.join(', ') : resData.message;
        showToast(`Fallo de Modificación: ${errorMsg}`, 'error');
      }
    } catch (error) {
      console.error('Error updating mission:', error);
      showToast('Error de red al actualizar la misión.', 'error');
    }
  });

  // DELETE: Delete mission
  confirmDeleteBtn.addEventListener('click', async () => {
    const id = document.getElementById('deleteMissionId').value;
    
    try {
      const response = await fetch(`${API_URL}/${id}`, {
        method: 'DELETE'
      });

      const resData = await response.json();

      if (response.ok) {
        showToast(resData.message || 'Misión eliminada del registro.', 'success');
        bootstrapDeleteModal.hide();
        fetchMissions();
      } else {
        showToast(`Fallo al purgar: ${resData.message}`, 'error');
      }
    } catch (error) {
      console.error('Error deleting mission:', error);
      showToast('Error de red al eliminar la misión.', 'error');
    }
  });

  // --- Real-time Local Filtering & Search ---

  function applyFilters() {
    const searchTerm = searchFilter.value.toLowerCase().trim();
    const statusVal = statusFilter.value;

    const filtered = allMissions.filter(mission => {
      // Check title match
      const titleMatch = mission.title.toLowerCase().includes(searchTerm) || 
                         mission.destination.toLowerCase().includes(searchTerm) ||
                         mission.commander.toLowerCase().includes(searchTerm);
      
      // Check status match
      const statusMatch = statusVal === 'ALL' || mission.status === statusVal;

      return titleMatch && statusMatch;
    });

    renderMissions(filtered);
  }

  // Bind filter events
  searchFilter.addEventListener('input', applyFilters);
  statusFilter.addEventListener('change', applyFilters);

  // --- UI Utility Helper Functions ---

  function showLoader() {
    loader.classList.remove('d-none');
  }

  function hideLoader() {
    loader.classList.add('d-none');
  }

  // Toast System for Visual Feedback
  function showToast(message, type = 'success') {
    const toastEl = document.getElementById('statusNotification');
    const toastMessage = document.getElementById('notificationMessage');
    const toastIcon = document.getElementById('notificationIcon');
    
    // Set message
    toastMessage.textContent = message;
    
    // Reset classes
    toastEl.classList.remove('bg-toast-success', 'bg-toast-error', 'bg-toast-warning');
    toastIcon.className = 'bi';
    
    // Configure according to type
    if (type === 'success') {
      toastEl.classList.add('bg-toast-success');
      toastIcon.classList.add('bi-check-circle-fill', 'text-success');
    } else if (type === 'error') {
      toastEl.classList.add('bg-toast-error');
      toastIcon.classList.add('bi-exclamation-octagon-fill', 'text-danger');
    } else if (type === 'warning') {
      toastEl.classList.add('bg-toast-warning');
      toastIcon.classList.add('bi-exclamation-triangle-fill', 'text-warning');
    }
    
    // Initialize & Show Toast
    const toast = bootstrap.Toast.getOrCreateInstance(toastEl, { delay: 4000 });
    toast.show();
  }

  // Initial Load
  fetchMissions();
});
